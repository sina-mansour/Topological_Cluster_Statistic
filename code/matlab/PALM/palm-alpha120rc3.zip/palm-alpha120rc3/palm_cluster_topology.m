function [maxsize,clstat,sizes] = palm_cluster_topology(X,y,thr,opts,plm,varargin)
% This function is used to cluster an arbitrary input effect according to
% an input topology
% 
% Usage:
% [maxsize,clstat,sizes] = palm_cluster_topology(X,y,thr,opts,plm)
% 
% Inputs:
% - X    : Statistical map.
% - y    : Modality index (of those stored in the plm struct).
% - thr  : Cluster-forming threshold.
% - opts : Struct with PALM options.
% - plm  : Struct with PALM data.
% 
% Outputs:
% - maxsize : Largest cluster extent.
% - clstat  : Thresholded map with the cluster sizes (cluster statistic).
% - sizes   : Vector with all cluster sizes.
% 
% _____________________________________
% Sina Mansour L.
% Melbourne Neuropsychiatry Centre / University of Melbourne
% Dec/2021
% https://sina-mansour.github.io/

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
% PALM -- Permutation Analysis of Linear Models
% Copyright (C) 2015 Anderson M. Winkler
% 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% any later version.
% 
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% Threshold, convert to a sparse diagonal matrix:
spdiagX   = spdiags((X > thr)',0,length(X),length(X));

% Update adjacency to keep masked edges only
thr_adj   = (spdiagX * plm.Yadjacency{y} * spdiagX);

% Compute connected components
[C,sizes] = get_components(thr_adj);
clstat    = sizes(C);
maxsize   = max(sizes);

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
function [C,Csiz] = get_components(G)
% Finds the connected components. This function is faster than
% the graphconncomp.m from the Bioinformatics toobox.
% A "component" is a maximal set of nodes that are mutually reachable
% by their edge connections.
%
% Usage:
% [S,C,Csiz] = get_components(G)
%
% Inputs:
% - G    : n by n adjacency matrix.
% 
% Outputs:
% - C    : vector indicating to which component each node belongs.
% - Csiz : sizes of each component
% 
% Code modified from: https://www.alecjacobson.com/weblog/?p=4203

[p,~,r]  = dmperm(G+speye(size(G)));
C        = cumsum(full(sparse(1,r(1:end-1),1,1,size(G,1))));
C(p)     = C;
[~,~,ic] = unique(C);
Csiz     = accumarray(ic,1);
