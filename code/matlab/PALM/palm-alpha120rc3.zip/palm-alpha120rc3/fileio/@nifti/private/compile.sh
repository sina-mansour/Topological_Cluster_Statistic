#!/bin/sh
make distclean PLATFORM=octave
make PLATFORM=octave

